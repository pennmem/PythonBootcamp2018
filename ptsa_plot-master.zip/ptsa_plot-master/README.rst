ptsa_plot
=========

.. image:: https://travis-ci.org/pennmem/ptsa_plot.svg?branch=master
    :target: https://travis-ci.org/pennmem/ptsa_plot

Plotting and visualization utilities using all your favorite PTSA toppings.

Contributing
------------

This is a collaborative project meant to collect useful plotting and
visualization routines in one place. Please see ``CONTRIBUTING.md`` for
guidelines on how to get your own code included.
